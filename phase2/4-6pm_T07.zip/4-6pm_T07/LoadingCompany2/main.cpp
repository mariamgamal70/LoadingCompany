#include "CompanyClass.h"
#include "UIclass.h"
#include"LinkedList.h"
int main()
{
	CompanyClass Maestro;
	Maestro.SimulatorFunction();
}
